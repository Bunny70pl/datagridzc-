﻿using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp5
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public ObservableCollection<Grakomputerowa> gry { get; set; } = new ObservableCollection<Grakomputerowa>();
        public ObservableCollection<Grakomputerowa> gryDoWyswietlenia { get; set; } = new ObservableCollection<Grakomputerowa>();
        public List<string> gatunki { get; set; } = new List<string>();
        public MainWindow()
        {
            InitializeComponent();
            gry = new ObservableCollection<Grakomputerowa>();
            gatunki = new List<string>();
            WypelnijTablice();
            DataContext = this;
            KolumnaGatunek.ItemsSource = gatunki;
        }
        private void WypelnijTablice()
        {
            gry.Add(new Grakomputerowa("CS2", "FPS",16,true));
            gry.Add(new Grakomputerowa("Teteris", "Zrecznosciowa",6,false));
            gry.Add(new Grakomputerowa("LOL", "Fantasy",13,true));
            gry.Add(new Grakomputerowa("Fortnite", "FPS",12,true));
            gry.Add(new Grakomputerowa("Cyberpunk", "RPG",18,false));
            gatunki.Add("FPS");
            gatunki.Add("Fantasy");
            gatunki.Add("Zrecznosciowa");
            gatunki.Add("RPG");
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(wiekGraBox.Text, out int result))
            {
                if(mutiplayerGraCheck.IsChecked == true)
                {
                    gry.Add(new Grakomputerowa (nazwaGraBox.Text, gatunkiComboBox.Text, result, true));
                }
                else
                {
                    gry.Add(new Grakomputerowa(nazwaGraBox.Text, gatunkiComboBox.Text, result, false));
                }
            }
            else
            {
                MessageBox.Show("Wiek musi byc liczba");
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            gryDoWyswietlenia.Clear();
            for (int i = 0; i < gry.Count; i++) { 
                if (gry[i].Gatunek == gatunkiDowyswietlenia.Text) {
                    gryDoWyswietlenia.Add(gry[i]);
                }

            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if(int.TryParse(idDoUsuniecia.Text, out int result))
            {
                int liczbaUsunietych = 0;
                for (int i = 0; i < gry.Count; i++)
                {
                    Grakomputerowa gierkaDoKastracji = gry[i];
                    if (gierkaDoKastracji.id == result)
                    {
                        gry.Remove(gierkaDoKastracji);
                        liczbaUsunietych++;
                        break;
                    }
                }
                if (liczbaUsunietych <= 0)
                {
                    MessageBox.Show("Nie ma takiego id w tablicy");
                }

            }
            else
            {
                MessageBox.Show("Podaj liczbe!!");
            }
        }
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {

        }
    }
}