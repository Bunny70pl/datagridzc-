﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace WpfApp5
{
    public class Grakomputerowa
    {
        public string Nazwa { get; set; }
        public string Gatunek { get; set; }
        public int Wiek {  get; set; }
        public bool Mutiplayer { get; set; }
        public int id { get; set; }
        public static int liczbaWszystkich { get; set; }

        public Button przycisk { get; set; } = new Button();

        public Grakomputerowa(string nazwa, string gatunek, int wiek, bool mutiplayer)
        {
            Nazwa = nazwa;
            Gatunek = gatunek;
            Wiek = wiek;
            Mutiplayer = mutiplayer;
            id = liczbaWszystkich;
            liczbaWszystkich++;
            przycisk.Content = "Edytuj";
        }
    }
}
